/**
 * Created by sav on 2015/5/2.
 */
var send_data =
{
    "fb_id": "069654654565",
    "fb_name": "John",
    "real_name": "JJXX",
    "phone": "0955666555",
    "email": "sss@ddd.ccc",
    "address": "sdfsdfsdf", // 有要鄉鎮市再說
    "day": 2,   // 投票目 (第 n 天)
    "voted_city": 7 // 投票的城市 index
};

var recive_data =
{
    "res": "ok"
};