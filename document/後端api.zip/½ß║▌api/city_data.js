var city_data =
{
    "city_data":
    [
        // day 0, 起始點
        {
            "index": 0,
            "name_en": "Berlin",
            "name_ch": "柏林",
            "day": 0
        },
        // day 1
        {
            "index": 1,
            "name_en": "Rome",
            "name_ch": "羅馬",
            "day": 1
        },
        {
            "index": 2,
            "name_en": "Paris",
            "name_ch": "巴黎",
            "day": 1
        },
        {
            "index": 3,
            "name_en": "Edinburgh",
            "name_ch": "愛丁堡",
            "day": 1
        },
        // day 2
        {
            "index": 4,
            "name_en": "Nairobi",
            "name_ch": "奈洛比",
            "day": 2
        },
        {
            "index": 5,
            "name_en": "Cairo",
            "name_ch": "開羅",
            "day": 2
        },
        {
            "index": 6,
            "name_en": "St. Petersburg",
            "name_ch": "聖彼得堡",
            "day": 2
        },
        // day 3
        {
            "index": 7,
            "name_en": "Windhoek",
            "name_ch": "溫荷克",
            "day": 3
        },
        {
            "index": 8,
            "name_en": "Bombay",
            "name_ch": "孟買",
            "day": 3
        },
        {
            "index": 9,
            "name_en": "Moscow",
            "name_ch": "莫斯科",
            "day": 3
        },
        // day 4
        {
            "index": 10,
            "name_en": "Ushuaia",
            "name_ch": "烏斯懷亞",
            "day": 4
        },
        {
            "index": 11,
            "name_en": "Kuala Lumpur",
            "name_ch": "吉隆坡",
            "day": 4
        },
        {
            "index": 12,
            "name_en": "Beijing",
            "name_ch": "北京",
            "day": 4
        },
        // day 5
        {
            "index": 13,
            "name_en": "Melbourne",
            "name_ch": "墨爾本",
            "day": 5
        },
        {
            "index": 14,
            "name_en": "Singapore",
            "name_ch": "新加坡",
            "day": 5
        },
        {
            "index": 15,
            "name_en": "Hong Kong",
            "name_ch": "香港",
            "day": 5
        },
        // day 6
        {
            "index": 16,
            "name_en": "Taipei",
            "name_ch": "台北",
            "day": 6
        },
        {
            "index": 17,
            "name_en": "Tainan",
            "name_ch": "台南",
            "day": 6
        }
    ]
};